#include "Experiments/BenchmarkOptions.h"
#include <sstream>
#include <stdexcept>
#include <limits>
#include <charconv>
namespace BenchmarkOptions
{
uint32_t parseCount(const std::string& value)
{
    uint32_t result = 0;
    auto parsed = std::from_chars(value.data(), value.data() + value.size(), result);
    if (parsed.ec != std::errc{} || parsed.ptr != value.data() + value.size())
        throw std::runtime_error("Invalid numeric option: " + value);
    return result;
}
std::vector<std::string> split(const std::string& s)
{
    std::vector<std::string> result;
    std::stringstream ss(s);
    std::string v;
    while (std::getline(ss, v, ','))
        if (!v.empty())
            result.push_back(v);
    return result;
}
Options parse(int argc, char** argv)
{
    Options o;
    for (int i = 2; i < argc; ++i)
    {
        std::string a = argv[i];
        auto value = [&]()
        {
            if (i + 1 >= argc)
                throw std::runtime_error("Missing value for " + a);
            return std::string(argv[++i]);
        };
        if (a == "--output")
            o.output = value();
        else if (a == "--samples")
            o.samples = parseCount(value());
        else if (a == "--warmup")
            o.warmup = parseCount(value());
        else if (a == "--views")
            o.views = parseCount(value());
        else if (a == "--rotation-axes")
        {
            o.axisSteps = parseCount(value());
            if (!o.axisSteps || o.axisSteps > 360)
                throw std::runtime_error("Rotation axis steps must be 1..360.");
        }
        else if (a == "--blocks")
            o.blocks = parseCount(value());
        else if (a == "--instances")
            o.instances = parseCount(value());
        else if (a == "--width")
            o.width = parseCount(value());
        else if (a == "--height")
            o.height = parseCount(value());
        else if (a == "--geometries")
            o.shapes = split(value());
        else if (a == "--methods")
            o.methods = split(value());
        else if (a == "--capture-method")
            o.captureMethod = value();
        else if (a == "--msaa")
        {
            o.msaa.clear();
            for (auto s : split(value()))
                o.msaa.push_back(parseCount(s));
        }
        else if (a == "--no-depth")
            o.depth = false;
        else if (a == "--meshopt")
            o.ordering = "cache-overdraw";
        else if (a == "--ordering")
            o.ordering = value();
        else if (a == "--explicit-lod")
            o.explicitLod = true;
        else if (a == "--raster-metrics")
            o.rasterMetrics = true;
        else if (a == "--lit")
            o.lit = true;
        else if (a == "--queue-depth")
            o.queueDepth = parseCount(value());
        else if (a == "--quick")
            o.quick = true;
        else
            throw std::runtime_error("Unknown performance option: " + a);
    }
    if (o.quick)
    {
        o.samples = 8;
        o.warmup = 8;
        o.views = 1;
        o.blocks = 1;
        o.msaa = {1};
        o.shapes = {"sphere"};
        o.methods = {"Source", "CDT", "CDTFlip", "Heap3D", "HeapPlane"};
    }
    if (o.axisSteps)
        o.views = 3 * o.axisSteps;
    for (const auto& method : o.methods)
        if (isViewMethod(method) && !o.axisSteps)
            throw std::runtime_error("Single-pose projected methods require --rotation-axes.");
    if (!o.samples || !o.views || !o.blocks || !o.instances || !o.width || !o.height || o.shapes.empty() || o.methods.empty() ||
        o.msaa.empty())
        throw std::runtime_error("Performance options must be nonzero/nonempty.");
    for (auto s : o.msaa)
        if (s != 1 && s != 4)
            throw std::runtime_error("This study supports MSAA 1 or 4.");
    if (!o.queueDepth || o.queueDepth > 32)
        throw std::runtime_error("Queue depth must be 1..32.");
    if (o.lit && !o.depth)
        throw std::runtime_error("Lit comparisons require depth.");
    if (o.ordering != "native" && o.ordering != "cache" && o.ordering != "cache-overdraw")
        throw std::runtime_error("Ordering must be native, cache or cache-overdraw.");
    o.meshopt = o.ordering != "native";
    if (o.lit && o.explicitLod)
        throw std::runtime_error("Explicit LOD applies only to the texture benchmark.");
    return o;
}
std::array<double, 3> rotationDegrees(const Options& o, uint32_t view)
{
    if (!o.axisSteps)
        return {22.5 + 45 * (view % 2), 11.25 + 90 * (view / 2), 0};
    std::array<double, 3> angles{};
    angles.at(view / o.axisSteps) = 360.0 * (view % o.axisSteps) / o.axisSteps;
    return angles;
}
bool isViewMethod(const std::string& method)
{
    return method == "HeapQuadView" || method == "HeapQuadLag" || method == "HeapQuadWarm" || method == "HeapQuadWarmLag";
}
} // namespace BenchmarkOptions
